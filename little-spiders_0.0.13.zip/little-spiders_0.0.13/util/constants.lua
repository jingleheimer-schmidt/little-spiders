
local max_task_range = 45
local half_max_task_range = max_task_range / 2
local double_max_task_range = max_task_range * 2

return {
    max_task_range = max_task_range,
    half_max_task_range = half_max_task_range,
    double_max_task_range = double_max_task_range,
}
