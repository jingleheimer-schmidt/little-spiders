
local message = { "migration-message.0.1.1" }
game.print(message)
