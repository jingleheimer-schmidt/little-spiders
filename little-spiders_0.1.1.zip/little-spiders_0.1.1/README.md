## Little Spiders
a mod for factorio
https://mods.factorio.com/mod/little-spiders

---------------------
# Overview
This mod adds special locale for the [Spiderbots mod](https://mods.factorio.com/mod/spiderbots)

---------------------
# Features

- Renames Spiderbots from the [Spiderbots mod](https://mods.factorio.com/mod/spiderbots) to "Little Spiders"

---------------------
# Compatibility
There are currently no known mod compatibility issues. To report a compatibility issue, please make a post on the discussion page.

---------------------
# License
Little Spiders © 2023 by asher_sky is licensed under Attribution-NonCommercial-ShareAlike 4.0 International.
To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/4.0/
